#!/system/bin/sh

MODDIR="${0%/*}"
. "$MODDIR/common.sh"

attempt=0
max_attempts=30

while [ "$attempt" -lt "$max_attempts" ]; do
  abk_apply_runtime_policy

  if abk_policy_ready; then
    abk_log "runtime policy converged after $attempt attempts"
    exit 0
  fi

  attempt=$((attempt + 1))
  sleep 2
done

abk_log "runtime policy did not fully converge within ${max_attempts} attempts"
exit 0
