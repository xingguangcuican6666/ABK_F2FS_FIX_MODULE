#!/system/bin/sh

MODDIR="${0%/*}"
. "$MODDIR/common.sh"

abk_apply_runtime_policy
abk_log "post-fs-data policy applied"
