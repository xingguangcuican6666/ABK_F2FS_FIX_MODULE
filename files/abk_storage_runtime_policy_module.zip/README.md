## ABK Storage Runtime Policy Module

This is a standard Magisk / KernelSU module that enforces the currently
best-known runtime storage settings after boot.

### What it does

- resolves the `/data` block path from `/proc/mounts`
- supports both direct block devices like `sda34` and `dm-*` stacks
- forces `none` on every reachable queue that exposes it
- writes `0` to UFS `clkgate_enable`, `rpm_lvl`, and `spm_lvl` when the
  controller sysfs node exists

### Files

- `post-fs-data.sh`
  - first early attempt after `/data` is mounted
- `service.sh`
  - retries until the block devices and UFS sysfs nodes are ready

### Verification

After reboot, check:

```sh
cat /sys/class/block/<device>/queue/scheduler
cat /sys/devices/platform/soc/*ufshc*/clkgate_enable
cat /sys/devices/platform/soc/*ufshc*/rpm_lvl
cat /sys/devices/platform/soc/*ufshc*/spm_lvl
```
