#!/system/bin/sh

ABK_TAG="ABK-StoragePolicy"

abk_log() {
  log -t "$ABK_TAG" "$*"
}

abk_get_data_source() {
  awk '$2 == "/data" { print $1; exit }' /proc/mounts
}

abk_resolve_block_name() {
  local src="$1"
  local base

  [ -n "$src" ] || return 1
  base="${src##*/}"
  [ -n "$base" ] || return 1
  printf '%s\n' "$base"
}

abk_collect_queue_devices() {
  local dev="$1"
  local sys real parent slave

  [ -n "$dev" ] || return 0
  sys="/sys/class/block/$dev"
  [ -e "$sys" ] || return 0

  printf '%s\n' "$dev"

  real="$(readlink -f "$sys" 2>/dev/null)"
  if [ -n "$real" ] && [ -f "$real/partition" ]; then
    parent="$(basename "$(dirname "$real")")"
    if [ -n "$parent" ] && [ "$parent" != "$dev" ]; then
      printf '%s\n' "$parent"
    fi
  fi

  if [ -d "$sys/slaves" ]; then
    for slave in "$sys"/slaves/*; do
      [ -e "$slave" ] || continue
      abk_collect_queue_devices "$(basename "$slave")"
    done
  fi
}

abk_list_target_queues() {
  local src dev

  src="$(abk_get_data_source)"
  dev="$(abk_resolve_block_name "$src")" || return 1
  abk_collect_queue_devices "$dev" | awk '!seen[$0]++'
}

abk_set_queue_none() {
  local dev file sched

  abk_list_target_queues | while read -r dev; do
    [ -n "$dev" ] || continue
    file="/sys/class/block/$dev/queue/scheduler"
    [ -f "$file" ] || continue
    sched="$(cat "$file" 2>/dev/null)"
    case " $sched " in
      *" none "*)
        echo none > "$file" 2>/dev/null
        ;;
    esac
  done
}

abk_scheduler_ready() {
  local dev file sched found=0

  while read -r dev; do
    [ -n "$dev" ] || continue
    file="/sys/class/block/$dev/queue/scheduler"
    [ -f "$file" ] || continue
    found=1
    sched="$(cat "$file" 2>/dev/null)"
    case "$sched" in
      *"[none]"*)
        ;;
      *)
        return 1
        ;;
    esac
  done <<EOF
$(abk_list_target_queues)
EOF

  [ "$found" -eq 1 ]
}

abk_set_ufs_pm() {
  local node file

  for node in /sys/devices/platform/soc/*ufshc*; do
    [ -d "$node" ] || continue
    for file in clkgate_enable rpm_lvl spm_lvl; do
      if [ -w "$node/$file" ]; then
        echo 0 > "$node/$file" 2>/dev/null
      fi
    done
  done
}

abk_ufs_pm_ready() {
  local node found=0

  for node in /sys/devices/platform/soc/*ufshc*; do
    [ -d "$node" ] || continue
    found=1
    [ -r "$node/clkgate_enable" ] || return 1
    [ -r "$node/rpm_lvl" ] || return 1
    [ -r "$node/spm_lvl" ] || return 1
    [ "$(cat "$node/clkgate_enable" 2>/dev/null)" = "0" ] || return 1
    [ "$(cat "$node/rpm_lvl" 2>/dev/null)" = "0" ] || return 1
    [ "$(cat "$node/spm_lvl" 2>/dev/null)" = "0" ] || return 1
  done

  [ "$found" -eq 0 ] || return 0
}

abk_apply_runtime_policy() {
  abk_set_queue_none
  abk_set_ufs_pm
}

abk_policy_ready() {
  abk_scheduler_ready && abk_ufs_pm_ready
}
